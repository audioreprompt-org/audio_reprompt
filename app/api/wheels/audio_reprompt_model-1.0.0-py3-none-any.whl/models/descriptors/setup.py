import nltk

nltk.download("punkt")
nltk.download("stopwords")
nltk.download("averaged_perceptron_tagger")
nltk.download("wordnet")
nltk.download("averaged_perceptron_tagger_eng")
nltk.download("omw-1.4")
